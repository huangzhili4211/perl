#!/usr/bin/perl -w
use strict;
use Cwd;
use File::Basename;
my $path = getcwd;

my $outpath = $path . "/getdiff";
mkdir $outpath unless -d $outpath;

my $in = "Summary-Result.txt";
my $FC = 1.5;
$FC = $ARGV[0] if($ARGV[0]);
my @uniqratio;
open SR,"<$in";
chomp (my $firstline = <SR>);
close SR;
my @Firstarr = split "\t",$firstline;
#map{push (@uniqratio,$1),if $_ =~ /^(\d*:\d*)$/} @Firstarr;
map{push (@uniqratio,$1),if ($_ =~ /^([\d\D]*:[\d\D]*)$/ && $_ !~ /\s+/) && $_ !~ /mix/} @Firstarr;
#print "@uniqratio\n";

###########��ò��쵰���б�#################
my $l;
my %headHash;
my %finHash;
my %statHash;
open DIF,"<$in";
while(<DIF>){
	$l++;
	chomp;
	my @items = split "\t";
	if ($l == 1) {
		for (my $i = 0; $i <= $#items; $i ++) {
			$headHash{$items[$i]} = $i;
		}
		foreach (@uniqratio) {
			(my $out_diff = $_) =~ s/:/-/;
			$out_diff .= "_diff.txt";
			$finHash{$_} = $out_diff;
			open TMP, ">$outpath/$out_diff";
			print TMP "N\tAccession\tName\tDiff_state\t$_\tPVal $_\n";
			close TMP;
		}
	}else {
		for (my $k = 0; $k <= $#uniqratio; $k ++) {
			my $fc = $items[$headHash{$uniqratio[$k]}];
			my $pv = $items[$headHash{"PVal " . $uniqratio[$k]}];
			if ($fc ne "--") {
				$statHash{$uniqratio[$k]}{"Total"} ++;
			}
			next if ($pv eq "--" || $pv >0.05 || $fc eq "--" );
			my $stu;
			if ($fc >= $FC) {
				$stu = 'up';
				$statHash{$uniqratio[$k]}{"up"} ++;
				$statHash{$uniqratio[$k]}{"Alldiff"} ++;
			}elsif ($fc <= 1/$FC) {
				$stu = 'down';
				$statHash{$uniqratio[$k]}{"down"} ++;
				$statHash{$uniqratio[$k]}{"Alldiff"} ++;
			}else {
				next;
			}
			my $L = $l - 1;
			my $NewLine = "$L\t$items[$headHash{'Accession'}]\t$items[$headHash{'Name'}]\t$stu\t$fc\t$pv\n";
			open OUT,">>","$outpath/$finHash{$uniqratio[$k]}";
			print OUT "$NewLine";
			close OUT;
		}
	}
}
close DIF;

my $staf = "Alldiff_stat.txt";
open STAT,">>","$outpath/$staf";
my @stats = ("Total", "up", "down", "Alldiff");
print STAT "\|FC\|=$FC\n";
my $stats = join "\t", @stats;
print STAT "\t$stats\n";
foreach my $cp (sort {$a cmp $b} keys %statHash) {
	my @value;
	map	{push (@value, $statHash{$cp}{$_})} @stats;
	my $value = join "\t", @value;
	print STAT "$cp\t$value\n";
}
close STAT;


##### get down/up_ID.fasta��.glist #####
my %fastaHash;
open FA,"<","All_ID.fa";
$/='>';<FA>;$/="\n";
while(<FA>){
	chomp;
	my $name=$_;
	$/='>';
	my $con=<FA>;
	chomp $con;
	$con=~s/\n//g;
	$/="\n";
	my $id;
	my $acc = $1 if $name =~ /([^ ]+)/;
	my $des = $1 if $name =~ /[^ ]+(.*)/;
	$id = $1 if $acc =~ /(gi\|[0-9]*)/;
	$id = $acc if $acc =~ /^tr|/ || $acc =~ /^sp|/;
	$fastaHash{$id} = ">$id $des\n$con\n";
}
close FA;

my @fiarr = glob "$outpath/*_diff.txt";
foreach (sort {$a cmp $b} @fiarr){
	my $f = basename $_;
	my $cp = $1 if $f =~ /([^_]+)/;
	(my $ncp = $cp )=~ s/-/:/g;
	print "$ncp\n";
	my $l;
	my %headHash;
	my $downf = $cp ."_down_ID.fa";
	my $upf = $cp . "_up_ID.fa";
	my $glist = $cp . ".glist";
	my $stup;
	my $stdown;
	open DOWN,">$outpath/$downf";
	open UP,">$outpath/$upf";
	open IN,"<$outpath/$f";
	open GL,">$outpath/$glist";
	while(<IN>){
		$l ++;
		chomp;
		my @items = split "\t";
		if ($l == 1){
			for (my $i = 0; $i <= $#items; $i++){
				$headHash{$items[$i]} = $i;
			}
		}else {
			my $loged = log($items[$headHash{$ncp}])/log(2);
			print GL "$items[$headHash{'Accession'}]\t$loged\n";
			print UP "$fastaHash{$items[$headHash{'Accession'}]}" if $items[$headHash{'Diff_state'}] eq 'up';
			print DOWN "$fastaHash{$items[$headHash{'Accession'}]}"  if $items[$headHash{'Diff_state'}] eq 'down';
		}
	}
	close DOWN;
	close UP;
	close GL;
	close IN;
}

	