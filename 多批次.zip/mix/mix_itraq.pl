#!/usr/bin/perl -w
use strict;
use diagnostics;
use Cwd;
use Getopt::Long;
use File::Path qw(mkpath);
use File::Basename;
use Bio::Tools::SeqStats;
use Spreadsheet::WriteExcel;

our $nowPath = getcwd;
our $R = "R";
our $prjdir = $nowPath;

my $file = "SummaryResult.txt";
open SR, "<SummaryResult.txt";
chomp(my $firl = <SR>);
my @Heads = split /\t/, $firl;
close SR;
my %Hash;
my %allhash;
our @markers = grep{/\d*:\d*/} @Heads;
my @marks = @markers;
my @sps = ('0h:mix', '4h:mix', '12h:mix', '24h:mix');
my %sampleHash;
my @headArray = ("N", "Accession", "Name", "Species", "Protein Mass", "Protein Length");
for (my $i = 0; $i <= $#sps ; $i++) {
	my @items = splice @marks, 0, 3;
	$sampleHash{$sps[$i]} = \@items;
	#print "$sps[$i]\t@items\n";
	push (@headArray, @items, $sps[$i]);
}
#print "@headArray\n";

my @compares = ('2h:0h',  '24h:8h');
my %hash = read_protein_file($file);

foreach (sort {$a cmp $b} @compares) {
	my $rh = $_;
	my $pvalueHead = "PVal ".$_;
	my $qvalueHead = "Qval ".$_;
	my $sdHead = "SD ".$_;
	push(@headArray,$rh,$sdHead,$pvalueHead,$qvalueHead);
}

my %hash4Pvalue = ();
my %tmpRatioHash = ();

######����Ƚ���ľ�ֵ����׼��######
foreach my $acc (keys %hash) {
	#$allhash{$acc}{"Accession"} = $acc;
	foreach my $cp (sort {$a cmp $b} @compares) {
		my $cp1 = $1 . ":mix" if $cp =~ /(.*):(.*)/;
		my $cp2 = $2 . ":mix"  if $cp =~ /(.*):(.*)/;
		my @marks1 = @{$sampleHash{$cp1}}; 
		my @marks2 = @{$sampleHash{$cp2}};                 #$cp=$1:mix/$2:mix��cp�Ƚ������������Ƚ�����ɵģ�
		my @ratios = ();
=pod
############����A�ظ���*����B�ظ��� ��Ratio����2����3�ظ������������3*3��Ratio��
		for (my $i = 0; $i <= $#marks1; $i++) {
			my $abund1 = exists $hash{$acc}{$marks1[$i]}? $hash{$acc}{$marks1[$i]} : 'NA';
			for (my $j = 0 ; $j <= $#marks2; $j++) {
				my $abund2 = exists $hash{$acc}{$marks2[$j]}? $hash{$acc}{$marks2[$j]} : 'NA';
				my $ratio;
				if ($abund1 eq "NA" || $abund2 eq "NA" ) {
					$ratio = "NA";
				}elsif ($abund2 ne "NA" && $abund2 != 0 && $abund1 ne "NA") {
					$ratio = $abund1 / $abund2;
				}elsif ($abund1 == 0 || $abund2 == 0) {
					$ratio = 0;
				}else {
					$ratio = "NA";
				}
				push (@ratios, $ratio) if ($ratio ne "NA" && $ratio != 0);
			}
		}
=cut
############��2����3�ظ������������3��Ratio############
		for (my $i = 0; $i <= $#marks1; $i++) {
			my $abund1 = exists $hash{$acc}{$marks1[$i]}? $hash{$acc}{$marks1[$i]} : 'NA';
			my $abund2 = exists $hash{$acc}{$marks2[$i]}? $hash{$acc}{$marks2[$i]} : 'NA';
			my $ratio;
			if ($abund1 eq "NA" || $abund2 eq "NA" ) {
				$ratio = "NA";
			}elsif ($abund2 ne "NA" && $abund2 != 0 && $abund1 ne "NA") {
				$ratio = $abund1 / $abund2;
			}elsif ($abund1 == 0 || $abund2 == 0) {
				$ratio = 0;
			}else {
				$ratio = "NA";
			}
			push (@ratios, $ratio) if ($ratio ne "NA" && $ratio != 0);
		}


		my $mean = get_mean(@ratios);
		my $sdvalue = get_sd(@ratios);
		my $ratioHead = $cp;
		my $sdHead = 'SD '.$cp;
		$allhash{$acc}{$ratioHead} = $mean;
		$allhash{$acc}{$sdHead} = $sdvalue;
		my @logRatios = ();
		map{my $loged = log($_)/log(2) if($_!=0);push(@logRatios,$loged) if($_!=0)} @ratios;
		$hash4Pvalue{$cp}{$acc} = \@logRatios;
	}
}

######����Ƚ����Pֵ��qֵ######
foreach my $cp (sort {$a cmp $b} keys %hash4Pvalue) {
	my %pvalueHash = ();
	my %qvalueHash = ();
	(my $cpn = $cp) =~ s/:/-/g;
	my $file4Pvalue = $cpn.".4pvl";
	open OUT1,">$file4Pvalue" or die;
	foreach my $acc (keys %{$hash4Pvalue{$cp}}) {
		my @ratios = @{$hash4Pvalue{$cp}{$acc}};
		my $rr = join ",",@ratios;
		print OUT1"$acc\t$rr\n" ;#if @ratios > 2 ;
	}
	close OUT1;
	get_pvalue2($cpn, $file4Pvalue,\%pvalueHash);               #����ÿ���±Ƚ����pvalue��������%pvalueHash��
	%qvalueHash = BenjaminiCorrelation(\%pvalueHash);
	my $pvalueHead = "PVal ".$cp;
	my $qvalueHead = "Qval ".$cp;
	foreach my $acc (keys %hash) {
		my $pval = "--";
		my $qval = "--";
		$pval = $pvalueHash{$acc}{$cp} if exists $pvalueHash{$acc}{$cp};
		$qval = $qvalueHash{$acc}{$cp} if exists $qvalueHash{$acc}{$cp};
		$allhash{$acc}{$pvalueHead} = $pval;
		$allhash{$acc}{$qvalueHead} = $qval;
	}
}
###########################################################

write_output_result(\%Hash,\%allhash,\@headArray);

######��ȡ�����κϲ���ı���######
sub read_protein_file {
	my $file = shift;
	my %headHash = ();
	my $l = 0;
	my %inhash = ();
	open IN,"<$file" or die;
	while (<IN>) {
		chomp;
		$l ++;
		my @items = split /\t/;
		if ($l == 1) {
			for(my $i=0;$i<=$#items;$i++) {
				$headHash{$items[$i]} = $i;
			}
			@headArray = @items;
		}else {
			my $N = $items[$headHash{'N'}];
			my $id = $items[$headHash{'Accession'}];
			$Hash{$N}{$id} = \@items;
			foreach my $marker (@markers) {
				my $abund = defined $items[$headHash{$marker}] && $items[$headHash{$marker}] =~ /[\d\D]+/? $items[$headHash{$marker}] : 0;      #�жϱ���Ƿ���ڣ�����ʱΪԭʼֵ��������ʱ��ֵΪNA��
				$abund = "NA" if $abund eq "-";
				$inhash{$id}{$marker} = $abund;
			}
		}
	}
	close IN;
	return %inhash;
}

########################################


sub write_output_result {
	my ($A,$B,$C) = @_;
	my %Hash1 = %$A;
	my %Hash2 = %$B;
	my @headArray = @$C;
	my $workbookFile = 'Summary-Result.xls';
	my $outFile = 'Summary-Result.txt';
	open OUT,">$prjdir/$outFile" || die "cant open $prjdir/$outFile:$!";
	my $workbook = Spreadsheet::WriteExcel->new("$prjdir/$workbookFile");
	my %font = (
		font  => 'New Times Roman',
		size  => 11,
		color => 'white',
		bold  => 1,
		align => 'center',
		bg_color => 'purple',
		valign => 'vcenter',
		text_wrap => 1,
	);
	my %font2 = (
		font => 'New Times Roman',
		size => 11,
		pattern => 0,
		color => 'black',
	);
	my $format_head = $workbook -> add_format(%font);
	my $format_cont = $workbook -> add_format(%font2);
	my $sheetName = 'Summary-Result';
	my $worksheet = $workbook -> add_worksheet($sheetName);
	my $columNum = @headArray;
	my $headString = join "\t",@headArray;
	print OUT"$headString\n";
	$worksheet -> freeze_panes('A2'); # Freeze the first row
	$worksheet->set_column('A:C', 20);
	$worksheet -> set_column(0,$columNum,15);
	$worksheet -> write_row(0,0,\@headArray,$format_head);
	my $cp_n = @compares;
	my $start = $columNum - ($cp_n * 4);
	my @addhead = splice @headArray, $start, $cp_n * 4;
	my $row = 0;
	foreach my $N (sort {$a <=> $b}keys %Hash1) {
		foreach my $acc (keys %{$Hash1{$N}}) {
			my @tmpArray = @{$Hash1{$N}{$acc}};
			foreach my $head (@addhead) {
				my $value = exists $Hash2{$acc}{$head}? $Hash2{$acc}{$head}:'--';
				push(@tmpArray,$value);
			}
			$worksheet -> write(++$row,0,\@tmpArray,$format_cont);
			my $outLine = join "\t",@tmpArray;
			print OUT"$outLine\n";
		}
	}
	$workbook -> close();
}

################################################


sub get_pvalue2{
	my ($mark,$f,$hash_ref) = @_;
	my %hash = ();
	my $pvalueF = $mark.'_pval.txt';
	$mark =~ s/-/:/;
	my $R_code1 = <<TTEST;
c <- file("$prjdir/$f","r")
while(TRUE) {
	r1<-readLines(c,n=1)
	if(length(r1) == 0) {
	break
    }else {
	r<-strsplit(r1,split="\t")
	str<-r[[1]][1]
	#str<-as.numeric(str[[1]])
	abunds1 <- r[[1]][2]
	abund11<-strsplit(abunds1[[1]],split=",")	
	abund1<-as.numeric(abund11[[1]])
     if(length(unique(abund1))==1&&length(abund1)>1){
		cc<-c(str,0)
		}else if(length(unique(abund1))==1&&length(abund1)==1){
			next
			}else{
	t<-t.test(abund1,mu=0)
	cc<-c(str,t\$p.value)       
         }
   
	cat(cc,file="$pvalueF",sep="\t",append=TRUE)
	cat("\n",file="$pvalueF",append=TRUE)
    }
}
close(c)
TTEST
	open R,"| $R --vanilla --slave" or die "$!";
	print R $R_code1;
	close R;
	open PF,"<$pvalueF" or die"cant open result.p:$!";
	while(<PF>) {
		chomp;
		my @items = split /\t/;
		#$hash{$items[0]} = $items[1];
		$hash_ref -> {$items[0]} -> {$mark} = $items[1];
	#print "$items[0]-----$items[1]\n";
	}
	close PF;
	#unlink $pvalueF;
	#unlink $f;
	return %hash;
}

##########################################################################


sub BenjaminiCorrelation {
    my $h = shift;
    my %hash = %$h;
    #my $m = scalar (keys %hash);
    my %outHash = ();
    my %tmpHash = ();
    foreach my $n (keys %hash) {
	foreach my $samp (keys %{$hash{$n}}) {
	    my $pvalue = $hash{$n}{$samp};
	    #$tmpHash{$samp}{$n}=$pvalue;
	    $tmpHash{$samp}{$n}=$pvalue if($pvalue ne "--");
	}
    }
    foreach my $samp (keys %tmpHash) {
	my $i = 0;
	 my $m=scalar(keys %{$tmpHash{$samp}});
	 print"$m\n";
	foreach my $n (sort {$tmpHash{$samp}{$a} <=> $tmpHash{$samp}{$b}} keys %{$tmpHash{$samp}}) {
	    $i ++;
	    my $pvalue = $tmpHash{$samp}{$n};
	    my $q = $m*$pvalue/$i;
	    $outHash{$n}{$samp} = $q;
	}
    }
    return %outHash;
}

########################################


sub get_mean{
	my @ratio=@_;
	my @finalratio;
	my $sum;
	map{push(@finalratio,$_) if($_!=0)} @ratio;
	map{$sum+=$_} @finalratio;
	my $meanRatio;
	if(@finalratio>=1){
		$meanRatio=$sum/@finalratio;
  }else{
  	$meanRatio="--"; 		
    }
      	
  my @finalratio1=sort{$a <=>$b} @finalratio;
	my $n=scalar @finalratio1;
	my $median;
	if($n==0){
		$median="--";
		}else{
	if($n%2==0){
		$median=($finalratio1[($n/2)-1]+$finalratio1[($n/2)])/2;		
	}elsif($n%2==1){
		$median=$finalratio1[($n-1)/2];		
		}
	}	
	#print"@finalratio---$median\n";
	my $sumsd;
	map{my  $sum1=($_-$meanRatio)*($_-$meanRatio);$sumsd+=$sum1;} @finalratio;
	my $sd;

	if(@finalratio>1){
			$sd=sqrt($sumsd/((@finalratio)-1));	
    } else{
	     $sd="--";
	}
	#print"$ret\n";
	#my @result=($meanRatio,$median,$sd);
	
	
	#print"$meanRatio\n";
	return $meanRatio;
	
	
	}
	
	
	sub get_sd{
	my @ratio=@_;
	my @finalratio;
	my $sum;
	map{push(@finalratio,$_) if($_!=0)} @ratio;
	map{$sum+=$_} @finalratio;
	my $meanRatio;
	if(@finalratio>=1){
		$meanRatio=$sum/@finalratio;
  }else{
  	$meanRatio="--"; 		
    }
      	
  my @finalratio1=sort{$a <=>$b} @finalratio;
	my $n=scalar @finalratio1;
	my $median;
	if($n==0){
		$median="--";
		}else{
	if($n%2==0){
		$median=($finalratio1[($n/2)-1]+$finalratio1[($n/2)])/2;		
	}elsif($n%2==1){
		$median=$finalratio1[($n-1)/2];		
		}
	}	
	#print"@finalratio---$median\n";
	my $sumsd;
	map{my  $sum1=($_-$meanRatio)*($_-$meanRatio);$sumsd+=$sum1} @finalratio;
	my $sd;

	if(@finalratio>1){
			$sd=sqrt($sumsd/((scalar @finalratio)-1));
    } else{
	     $sd="--";
	}
	#print"$ret\n";
	#my @result=($meanRatio,$median,$sd);
	
	#return $meanRatio;
	return $sd;
	
	}
	