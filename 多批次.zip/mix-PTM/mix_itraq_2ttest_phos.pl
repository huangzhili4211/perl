#!/usr/bin/perl -w
use strict;
use diagnostics;
use Cwd;
use Getopt::Long;
use File::Path qw(mkpath);
use File::Basename;
use Bio::Tools::SeqStats;
use Spreadsheet::WriteExcel;

our $nowPath = getcwd;
our $R = "R";
our $prjdir = $nowPath;

my $file = "SummaryResult.txt";
open SR, "<SummaryResult.txt";
chomp(my $firl = <SR>);
my @Heads = split /\t/, $firl;
close SR;
my %Hash;
my %allhash;
our @markers = grep{/\d*:\d*/} @Heads;
my @marks = @markers;
my @sps = ('0h:mix', '2h:mix', '8h:mix', '24h:mix');
my %sampleHash;
my @headArray = ('Index', 'Sequence', 'Phos_seq', 'Modification', 'Length', 'Cleavages', 'Theor MW', 'Charge', 'Batch-1 N', 'Batch-1 Accessions', 'Batch-2 N', 'Batch-2 Accessions');
my $sn = @headArray;
#my @headArray = not grep{/\d*:\d*/} @Heads;
#print "@headArray\n";
for (my $i = 0; $i <= $#sps ; $i++) {
	my @items = splice @marks, 0, 3;
	$sampleHash{$sps[$i]} = \@items;
	#print "$sps[$i]\t@items\n";
	push (@headArray, @items, $sps[$i]);
}
#print "@headArray\n";
my @compares = ('2h:0h',  '8h:0h', '8h:2h', '24h:0h', '24h:2h', '24h:8h');
my %hash = read_protein_file($file);
foreach (sort {$a cmp $b} @compares) {
	my $rh = $_;
	my $pvalueHead = "PVal ".$_;
	my $qvalueHead = "Qval ".$_;
	#my $sdHead = "SD ".$_;
	push(@headArray,$rh,$pvalueHead,$qvalueHead);
}

##########����Ƚ���(2h:0h)�ı�ֵ��Pvalue��Qvalue##########
my %hash4Pvalue = ();
foreach my $acc (keys %hash) {
	#$allhash{$acc}{"Accession"} = $acc;
	foreach my $cp (sort {$a cmp $b} @compares) {
		my $cp1 = $1 . ":mix" if $cp =~ /(.*):(.*)/;
		my $cp2 = $2 . ":mix"  if $cp =~ /(.*):(.*)/;
		my $r1 = $allhash{$acc}{$cp1};
		my $r2 = $allhash{$acc}{$cp2};
		my $cpR = get_fc($r1,$r2);
		$allhash{$acc}{$cp} = $cpR;                       #����FC
		
	##########��ȡ�������ڼ���pvalue##########
		my @marks1 = @{$sampleHash{$cp1}}; 
		my @marks2 = @{$sampleHash{$cp2}};
		my @logRatios1 = ();
		my @logRatios2 = ();
		map{my $ratio =$hash{$acc}{$_}; push(@logRatios1,log($ratio)/log(2)) if($ratio ne "NA" && $ratio != 0)} @marks1;
		map{my $ratio =$hash{$acc}{$_}; push(@logRatios2,log($ratio)/log(2)) if($ratio ne "NA" && $ratio != 0)} @marks2;
		$hash4Pvalue{$cp}{$acc}{$cp1} = \@logRatios1;
		$hash4Pvalue{$cp}{$acc}{$cp2} = \@logRatios2;
	}
}
#########�������˫����ttest���ļ�,������p��qvalue###########
foreach my $cp (sort {$a cmp $b} keys %hash4Pvalue) {
	my %pvalueHash = ();
	my %qvalueHash = ();
	(my $cpn = $cp) =~ s/:/-/g;
	my $file4Pvalue = $cpn.".4pvl";
	open OUT1,">$file4Pvalue" or die;
	foreach my $acc (keys %{$hash4Pvalue{$cp}}) {
		my @sms = keys %{$hash4Pvalue{$cp}{$acc}};
		my @ratios1 = @{$hash4Pvalue{$cp}{$acc}{$sms[0]}};
		my @ratios2 = @{$hash4Pvalue{$cp}{$acc}{$sms[1]}};
		next if (@ratios1 == 0 || @ratios2 == 0);
		if (@ratios1 >= 2 && @ratios2 >= 2) {
			my $ratio1 = join ";", @ratios1;
			my $ratio2 = join ";", @ratios2;
			print OUT1"$acc\t$ratio1\t$ratio2\n";
		}
	}
	close OUT1;
	get_pvalue2($cpn, $file4Pvalue,\%pvalueHash);               #����ÿ���±Ƚ����pvalue��������%pvalueHash��
	%qvalueHash = BenjaminiCorrelation(\%pvalueHash);
	my $pvalueHead = "PVal ".$cp;
	my $qvalueHead = "Qval ".$cp;
	foreach my $acc (keys %hash) {
		my $pval = "--";
		my $qval = "--";
		$pval = $pvalueHash{$acc}{$cp} if exists $pvalueHash{$acc}{$cp};
		$qval = $qvalueHash{$acc}{$cp} if exists $qvalueHash{$acc}{$cp};
		$allhash{$acc}{$pvalueHead} = $pval;
		$allhash{$acc}{$qvalueHead} = $qval;
	}
}
###########################################################

write_output_result(\%Hash,\%allhash,\@headArray);                          #�����ָ�ʽ������ս����.txt��.xlsx��


######��ȡ�����κϲ���ı���######
sub read_protein_file {
	my $file = shift;
	my %headHash = ();
	my $l = 0;
	my %inhash = ();
	open IN,"<$file" or die;
	while (<IN>) {
		chomp;
		$l ++;
		my @items = split /\t/;
		if ($l == 1) {
			for(my $i=0;$i<=$#items;$i++) {
				$headHash{$items[$i]} = $i;
			}
		}else {
			my $N = $items[$headHash{'Index'}];
			my $id = $items[$headHash{'Phos_seq'}];
			foreach my $sm (keys %sampleHash) {
				my @marks = @{$sampleHash{$sm}};
				#print "$sm\t@marks\n";
				my @abs;
				foreach (@marks) {
					my $abund = defined $items[$headHash{$_}] ? $items[$headHash{$_}] : "";      #�жϱ���Ƿ���ڣ�����ʱΪԭʼֵ��������ʱ��ֵΪNA��
					#print "$abund\n";
					$allhash{$id}{$_} = $abund;
					push (@abs, $abund) if ($abund ne "--" && $abund ne "");
					$abund = "NA" if ($abund eq "--" || $abund eq "");
					$inhash{$id}{$_} = $abund;
				}
				#print "@abs\n";
				my $lab = "--";
				$lab = get_mean(@abs) if @abs >=1;
				$allhash{$id}{$sm} = $lab;
			}
			my @sames = splice @items, 0, $sn;
			$Hash{$N}{$id} = \@sames;
		}
	}
	close IN;
	return %inhash;
}

########################################

sub write_output_result {
	my ($A,$B,$C) = @_;
	my %Hash1 = %$A;
	my %Hash2 = %$B;
	my @headArray = @$C;
	my $workbookFile = 'Summary-Result.xls';
	my $outFile = 'Summary-Result.txt';
	open OUT,">$prjdir/$outFile" || die "cant open $prjdir/$outFile:$!";
	my $workbook = Spreadsheet::WriteExcel->new("$prjdir/$workbookFile");
	my %font = (
		font  => 'New Times Roman',
		size  => 11,
		color => 'white',
		bold  => 1,
		align => 'center',
		bg_color => 'purple',
		valign => 'vcenter',
		text_wrap => 1,
	);
	my %font2 = (
		font => 'New Times Roman',
		size => 11,
		pattern => 0,
		color => 'black',
	);
	my $format_head = $workbook -> add_format(%font);
	my $format_cont = $workbook -> add_format(%font2);
	my $sheetName = 'Summary-Result';
	my $worksheet = $workbook -> add_worksheet($sheetName);
	my $columNum = @headArray;
	my $headString = join "\t",@headArray;
	print OUT"$headString\n";
	$worksheet -> freeze_panes('A2'); # Freeze the first row
	$worksheet->set_column('A:C', 20);
	$worksheet -> set_column(0,$columNum,15);
	$worksheet -> write_row(0,0,\@headArray,$format_head);
	my @addhead = splice @headArray, $sn;
	my $row = 0;
	foreach my $N (sort {$a <=> $b}keys %Hash1) {
		foreach my $acc (keys %{$Hash1{$N}}) {
			my @tmpArray = @{$Hash1{$N}{$acc}};
			foreach my $head (@addhead) {
				my $value = exists $Hash2{$acc}{$head}? $Hash2{$acc}{$head}:'--';
				push(@tmpArray,$value);
			}
			$worksheet -> write(++$row,0,\@tmpArray,$format_cont);
			my $outLine = join "\t",@tmpArray;
			print OUT"$outLine\n";
		}
	}
	$workbook -> close();
}


################################################

sub get_fc{
	my ($a,$b) = @_;
	my $fc;
	if ($a eq "--" || $b eq "--") {
		$fc = "--";
	}elsif ($a > 0 && $b > 0) {
		$fc = $a / $b;
	}else {
		$fc = "--";
	}
	return $fc;
}

####################################################


sub get_pvalue2{
	my ($mark,$f,$hash_ref) = @_;
	my %hash = ();
	my $pvalueF = $mark.'_pval.txt';
	$mark =~ s/-/:/;
	print "$f\n";
	my $R_code1 = <<TTEST;
c <- file("$prjdir/$f","r")
while(TRUE) {
	r1<-readLines(c,n=1)
	if(length(r1) == 0) {
		break
	}else {
		r<-strsplit(r1,split="\t")
		str<-r[[1]][1]
		array1<-r[[1]][2]
      	array2<-r[[1]][3]
      	array1<-as.character(unlist(array1))
      	array1<-strsplit(array1,split=";")
      	array2<-as.character(unlist(array2))
      	array2<-strsplit(array2,split=";")
      	array1<-as.numeric(unlist(array1))
      	#array1<-log(array1,2)
      	array2<-as.numeric(unlist(array2))
      	#array2<-log(array2,2)
      	data <- c(str,array1,array2)
      	#print (array1)
      	#print (array2)
      	t<- t.test(array1,array2)
      	cc<- c(str,t\$p.value)
      }
      cat(cc,file="$pvalueF",sep="\t",append=TRUE)
      cat("\n",file="$pvalueF",append=TRUE)
    }
close(c)
TTEST
    	open R,"| $R --vanilla --slave" or die "$!";
	print R $R_code1;
	close R;
	open PF,"<$pvalueF" or die"cant open $pvalueF:$!";
	while(<PF>) {
		chomp;
		my @items = split /\t/;
		#$hash{$items[0]} = $items[1];
		$hash_ref -> {$items[0]} -> {$mark} = $items[1];
		#print "$items[0]-----$items[1]\n";
	}
	close PF;
	#unlink $pvalueF;
	#unlink $f;
	return %hash;
}


##########################################################################


sub BenjaminiCorrelation {
    my $h = shift;
    my %hash = %$h;
    #my $m = scalar (keys %hash);
    my %outHash = ();
    my %tmpHash = ();
    foreach my $n (keys %hash) {
	foreach my $samp (keys %{$hash{$n}}) {
	    my $pvalue = $hash{$n}{$samp};
	    #$tmpHash{$samp}{$n}=$pvalue;
	    $tmpHash{$samp}{$n}=$pvalue if($pvalue ne "--");
	}
    }
    foreach my $samp (keys %tmpHash) {
	my $i = 0;
	 my $m=scalar(keys %{$tmpHash{$samp}});
	 print"$m\n";
	foreach my $n (sort {$tmpHash{$samp}{$a} <=> $tmpHash{$samp}{$b}} keys %{$tmpHash{$samp}}) {
	    $i ++;
	    my $pvalue = $tmpHash{$samp}{$n};
	    my $q = $m*$pvalue/$i;
	    $outHash{$n}{$samp} = $q;
	}
    }
    return %outHash;
}

########################################


sub get_mean{
	my @ratio=@_;
	my @finalratio;
	my $sum;
	map{push(@finalratio,$_) if($_!=0)} @ratio;
	map{$sum+=$_} @finalratio;
	my $meanRatio;
	if(@finalratio>=1){
		$meanRatio=$sum/@finalratio;
	}else{
		$meanRatio=0; 		#$meanRatio="--";
    }
     my @finalratio1=sort{$a <=>$b} @finalratio;
	my $n=scalar @finalratio1;
	my $median;
	if($n==0){
		$median="--";
	}else{
		if($n%2==0){
			$median=($finalratio1[($n/2)-1]+$finalratio1[($n/2)])/2;
		}elsif($n%2==1){
			$median=$finalratio1[($n-1)/2];
		}
	}	
	#print"@finalratio---$median\n";
	my $sumsd;
	map{my  $sum1=($_-$meanRatio)*($_-$meanRatio);$sumsd+=$sum1;} @finalratio;
	my $sd;
	if(@finalratio>1){
		$sd=sqrt($sumsd/((@finalratio)-1));
	}else{
		$sd="--";
	}
	#print"$ret\n";
	#my @result=($meanRatio,$median,$sd);
	#print"$meanRatio\n";
	return $meanRatio;
}
	
	
sub get_sd{
	my @ratio=@_;
	my @finalratio;
	my $sum;
	map{push(@finalratio,$_) if($_!=0)} @ratio;
	map{$sum+=$_} @finalratio;
	my $meanRatio;
	if(@finalratio>=1){
		$meanRatio=$sum/@finalratio;
	}else{
		$meanRatio="--"; 		
    }
    
     my @finalratio1=sort{$a <=>$b} @finalratio;
	my $n=scalar @finalratio1;
	my $median;
	if($n==0){
		$median="--";
	}else{
		if($n%2==0){
			$median=($finalratio1[($n/2)-1]+$finalratio1[($n/2)])/2;
		}elsif($n%2==1){
			$median=$finalratio1[($n-1)/2];		
		}
	}
	#print"@finalratio---$median\n";
	my $sumsd;
	map{my  $sum1=($_-$meanRatio)*($_-$meanRatio);$sumsd+=$sum1} @finalratio;
	my $sd;

	if(@finalratio>1){
			$sd=sqrt($sumsd/((scalar @finalratio)-1));
    }else{
	     $sd="--";
	}
	#print"$ret\n";
	#my @result=($meanRatio,$median,$sd);
	
	#return $meanRatio;
	return $sd;
	
}
	