###############################
#����PTM�Ķ����кϲ������εĽ��######

#!/usr/bin/perl -w;
use strict;
my @flist = glob"Peptides_quant*";
my $n;
my @samehead = ('Sequence', 'Phos_seq', 'Modification', 'Length', 'Cleavages', 'Theor MW','Charge');
my @shead = ('N', 'Accessions');
my @cps;  #unique ratio within header line
my @shead1;
my @cps1;
my %allHash;

##########First step: read each file##########
foreach my $f (sort {$a cmp $b} @flist) {
	my $fn = $1 if $f =~ /(\d)/;
	if ($fn == 1) {
		open HE,"<$f";
		chomp(my $FirL = <HE>);
		@cps = split "\t",$FirL;
		@cps = grep{/^\d*:\d*/} @cps;
		close HE;
	}
	map {push(@shead1, "Batch-$fn " . $_)} @shead;
	map {push(@cps1, "Batch-$fn " . $_)} @cps;
	my $l;
	my %headHash;

	open IN,"<$f";
	while (<IN>) {
		chomp;
		$l ++;
		my @items = split /\t/;
		if ($l == 1) {
			for (my $i = 0; $i <= $#items; $i++) {
				$headHash{$items[$i]} = $i;
				#map {push(@headind, $i) if $items eq $_} @shead;
				#map {push(@headind, $i) if $items eq $_} @cps;
			}
		}else {
			my $seq = $items[$headHash{"Sequence"}];
			my $pseq = $items[$headHash{"Phos_seq"}];
			my $mody = $items[$headHash{"Modification"}];
			my @mods = split /; /, $mody;
			@mods = grep {/^Phospho/} @mods;
			$mody = join "; ", @mods;
			my $len = length($seq);
			$items[$headHash{"Modification"}] = $mody;
			$items[$headHash{"Length"}] = $len;
			#$allHash{$pseq}{'Length'} = $len;      #��ǰһ����˼һ��,�߼�����������
			map {$allHash{$pseq}{$_} = $items[$headHash{$_}]} @samehead;
			map {$allHash{$pseq}{"Batch-$fn " . $_} = $items[$headHash{$_}]} @shead;
			map {$allHash{$pseq}{"Batch-$fn " . $_} = $items[$headHash{$_}]} @cps;
		}
	}
}

##########Second step: combine##########
my @heads = ('Index');                                         #����ļ��ı�ͷ
push (@heads, @samehead,@shead1, @cps1);
my $n;
open COM, ">SummaryResult.txt";
my $headL = join "\t", @heads;
print COM "$headL\n";
foreach my $pseq (sort {$a cmp $b} keys %allHash) {
	$n ++;
	my @data;
	for (my $i = 0; $i <= $#heads; $i++) {
		my $datum = defined $allHash{$pseq}{$heads[$i]} ? $allHash{$pseq}{$heads[$i]}:"";
		$datum = $n if $heads[$i] eq 'Index';
		push (@data, $datum);
	}
	my $line = join "\t", @data;
	print COM "$line\n";
}

##########Third step: reorder header line ##########
my @reorder;
map {push (@reorder, $_) if $_ !~ /\d*:\d*/} @heads;        #����Ҫ����Ĳ���
for (my $i = 0; $i <= $#cps; $i++) {                                               #��Ҫ�Բ�ͬ������ͬ�Ƚ����������
	map {push (@reorder, $_) if $_ =~ /$cps[$i]/} @heads;
}

open SR,"<SummaryResult.txt";
open RSR,">reorder_SummaryResult.txt";
my $l;
my %headHash;
while (<SR>) {
	chomp;
	$l ++;
	my @items = split /\t/,;
	if ($l == 1) {
		for (my $i = 0; $i <= $#items; $i++) {
			$headHash{$items[$i]} = $i;
		}
		my $rheadline = join "\t", @reorder;
		print RSR "$rheadline\n";
	}else {
		my @data;
		map {push (@data, $items[$headHash{$_}])} @reorder;
		my $line = join "\t", @data;
		print RSR "$line\n";
	}
}
close SR;
close RSR;

