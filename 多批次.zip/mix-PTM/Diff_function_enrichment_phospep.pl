####��ȡ���쵰���ʵ�ע�ͺ͸�����Ϣ go_result.txt


#!/usr/bin/perl
use strict;
use warnings;
use Cwd;
use File::Path qw(mkpath);
use File::Path;
use File::Basename;
use Excel::Writer::XLSX;
my $path = getcwd;
my $originalpath = $path . "/before_combined_diff_Result";
my @ratio_index = glob "$originalpath/*_diff.txt";
my %head1Hash;
my %excelHash;
my $outPath = getcwd;
my $outFold = "Function_enrichment_summary";
mkpath("$outPath/$outFold", 0755) unless (-e "$outPath/$outFold");
$outPath = $outPath . "/" . $outFold;

##########Each Compare:Enrichment result##########
foreach my $ratio_index (@ratio_index) {
    $ratio_index = basename $ratio_index;
    $ratio_index =~ s/(.*)_diff.txt/$1/;
    my $go_path = $ratio_index . "_GO_enrichment";
    my $gopath = $path . "/Project_data/Enrichment/GO_enrichment/$go_path";
    my $go_file_C = $ratio_index . "_C.txt";
    my $go_file_P = $ratio_index . "_P.txt";
    my $go_file_F = $ratio_index . "_F.txt";
    my @file;
    push(@file, $go_file_C, $go_file_P, $go_file_F);
    my %goHash;
    my %goaccHash;
    my %gopng;
    my %goHash1;
    ##########GO file##########
    foreach my $file (@file) {
        open ENRICHMENT, "<$gopath/$file";
        #print"$gopath/$file\n";
        while (<ENRICHMENT>) {
            chomp;
            my @items = split "\t";
            my $acc = $items[5];
            my @acc = split ",", $acc;
            my $goid = $items[0];
            my $goacc = $items[1];
            my $p = $items[4];
            map {$goHash{$file}{$_}{$goid}++} @acc;
            $goaccHash{$file}{$goid} = $goacc;
            $gopng{$file}{$goacc} = $p;
            my $go = $goid . "," . $goacc;
            map {$goHash1{$file}{$_}{$go}++} @acc;
        }
    }
    ##########KEGG file##########
    my $keggpathway = $ratio_index . "_Pathway_enrichment";
    my $pathwayp = $path . "/Project_data/Enrichment/Pathway_enrichment/$keggpathway";
    my $pathwaypath1 = $ratio_index . ".path";
    open PATHWAY, "<$pathwayp/$pathwaypath1";
    my %pathwayHash;
    my %pathwayHash1;
    my %pathaccHash;
    my $linep;
    my %pathpngHash;
    while (<PATHWAY>) {
        chomp;
        $linep++;
        my @items = split "\t";
        if ($linep >= 2) {
            my $pro = $items[5];
            my @pro = split ";", $pro;
            my $pathid = $items[4];
            my $pathway = $items[0];
            my $p = $items[3];
            $pathaccHash{$pathid} = $pathway;
            $pathpngHash{$pathway} = $p;
            my $pathwayout = $pathid . "," . $pathway;
            foreach my $proid (@pro) {
                $pathwayHash{$proid}{$pathid}++;
                $pathwayHash1{$proid}{$pathwayout}++;
            }
        }
    }
    ##########Annotation result##########
    my $funpath = $path . "/Project_data/Function/All_ID_GO";
    open FUN, "<$funpath/All_ID.fa.GO2protein.xls";
    my @itemsf;
    my $linef;
    my %hash1;
    while (<FUN>) {
        chomp;
        my @items = split "\t";
        $linef++;
        if ($linef >= 2) {
            my $onto = $items[0];
            my $class = $items[1];
            my $id = $items[3];
            my @id = split "; ", $id;
            my $num = scalar @id;
            map {$hash1{$_}{$onto}{$class}++} @id;
        }
    }
    my $num1 = scalar(keys %hash1);
    print "$num1\n";
    my $cogpath = $path . "/Project_data/Function/All_ID_COG";
    open COG, "<$cogpath/All_ID.protein2cog.xls";
    my $linec;
    my @itemsc;
    my %hash2;
    while (<COG>) {
        chomp;
        $linec++;
        @itemsc = split "\t";
        if ($linec >= 2) {
            my $id = $itemsc[0];
            my $cog = $itemsc[7];
            $hash2{$id}{$cog} = 0;
        }
    }
    my $pathwaypath = $path . "/Project_data/Function/All_ID_Pathway";
    open PATHWAYF, "<$pathwaypath/All_ID.path";
    my $line3;
    my %hash3;
    my @items3;
    while (<PATHWAYF>) {
        chomp;
        $linef++;
        @itemsf = split "\t";
        if ($linef >= 2) {
            my $pathway = $itemsf[0];
            my $id = $itemsf[3];
            my @id;
            if ($id =~ /;/) {
                @id = split ";", $id;
            }
            else {
                push(@id, $id);
            }
            map {$hash3{$_}{$pathway}++} @id;
        }
    }

    ##########Read diff file##########
    my $diff_file = $ratio_index . "_diff.txt";
    open DIFF, "<$originalpath/$diff_file";
    my $line2;
    my %headHash;
    my %numHash;
    my $outfile = $ratio_index . "_go_result.txt";
    open GO, ">$outPath/$outfile";
    my $num;
    my %gopngHash;
    my %pathppng;
    my @filename;
    my @Aind;
    my $n;
    while (<DIFF>) {
        chomp;
        $line2++;
        my @items = split "\t";
        my @outgoid;
        my @out;
        my $go1 = "";
        my $gop = "";
        my $goc = "";
        my $gof = "";
        my $cog = "";
        my $pathway1 = "";
        my @go1;
        if ($line2 == 1) {
            print GO "$_\tGO_function(Biological_Process)\tGO_function(Cellular_Component)\tGO_function(Molecular_Function)\tCOG_function\tKegg_function\tGO_enrichment(Biological_Process)\tGO_enrichment(Cellular_Component)\tGO_enrichment(Molecular_Function)\tKegg_enrichment\n";
            my @head = (@items, "GO_function(Biological_Process)", "GO_function(Cellular_Component)", "GO_function(Molecular_Function)", "COG_function", "Kegg_function", "GO_enrichment(Biological_Process)", "GO_enrichment(Cellular_Component)", "GO_enrichment(Molecular_Function)", "Kegg_enrichment");
            my $head = join "\t", @head;
            $head1Hash{$ratio_index} = $head;
            for (my $i = 0; $i <= $#items; $i++) {
                $headHash{$items[$i]} = $i;
                push(@Aind, $i) if $items[$i] =~ /Accessions/;
            }
        }else {
        	my %accHash;
        	my $na;
           map {$accHash{$1} = $_ if $items[$_] =~ /^([^;]+)/} @Aind;
           foreach my $target (sort {$accHash{$a} <=> $accHash{$b}} keys %accHash) {
                $n++;
                print "$n\n";
                $na++;
                if (exists $hash1{$target}) {
                    if (exists $hash1{$target}{"biological_process"}) {
                        my @gop = keys %{$hash1{$target}{"biological_process"}};
                        $gop = join ";", @gop;
                    }
                    if (exists $hash1{$target}{"cellular_component"}) {
                        my @goc = keys %{$hash1{$target}{"cellular_component"}};
                        $goc = join ";", @goc;
                    }
                    if (exists $hash1{$target}{"molecular_function"}) {
                        my @gof = keys %{$hash1{$target}{"molecular_function"}};
                        $gof = join ";", @gof;
                    }
                }
                if (exists $hash2{$target}) {
                    my @cog = keys %{$hash2{$target}};
                    $cog = join "", @cog;
                }
                if (exists $hash3{$target}) {
                    my @pathway = keys %{$hash3{$target}};
                    $pathway1 = join ";", @pathway;
                }
                push(@out, $gop, $goc, $gof, $cog, $pathway1);
                my @gop_e;
                my @goc_e;
                my @gof_e;
                my $gop_e;
                my $goc_e;
                my $gof_e;
                foreach my $file (keys %goHash) {
                    push(@filename, $file);
                    my @goid;
                    my @goacc;
                    my @go;
                    if (exists $goHash{$file}{$target}) {
                        @gop_e = keys %{$goHash1{$file}{$target}} if ($file =~ /_P\.txt/);
                        @goc_e = keys %{$goHash1{$file}{$target}} if ($file =~ /_C\.txt/);
                        @gof_e = keys %{$goHash1{$file}{$target}} if ($file =~ /_F\.txt/);
                    }
                    $gop_e = join ";", @gop_e;
                    $goc_e = join ";", @goc_e;
                    $gof_e = join ";", @gof_e;
                }
                push(@out, $gop_e, $goc_e, $gof_e);
                my @pathwayid;
                my @pathwayacc;
                my @pathway;
                if (exists $pathwayHash{$target}) {
                    @pathwayid = keys %{$pathwayHash{$target}};
                    map {push(@pathwayacc, $pathaccHash{$_}) if (exists $pathaccHash{$_})} @pathwayid;
                    map {$pathppng{$pathaccHash{$_}}++ if (exists $pathaccHash{$_})} @pathwayid;
                    @pathway = keys %{$pathwayHash1{$target}};
                }
                my $pathwayid = join ";", @pathwayid;
                my $pathwayacc = join ";", @pathwayacc;
                my $pathway = join ";", @pathway;
                push(@out, $pathway);
                my $out = join "\t", @out;
                if ($na == 1) {
                    print GO "$_\t$out\n";
                    my @excelout = (@items, @out);
                    my $excelout = join "\t", @excelout;
                    $excelHash{$ratio_index}{$n} = $excelout;
                    #print "$n\n";
                }else {
                    my @nitems;
                    map {push(@nitems, "")} @items;
                    my $y = join "\t", @nitems;
                    print GO "$y\t$out\n";
                    my @excelout = (@nitems, @out);
                    my $excelout = join "\t", @excelout;
                    $excelHash{$ratio_index}{$n} = $excelout;
                    #print "$n\n";
                }
            }
        }
    }
}

my %font1 = (
    font      => "Times New Roman",
    size      => 11,
    color     => "white",
    align     => 'center',
    bg_color  => 'purple',
    valign    => 'vcenter',
    text_wrap => 1,
    bold      => 1,
);
my %font2 = (
    font    => "Times New Roman",
    size    => 11,
    color   => "black",
    pattern => 0,
);
my $outfile1 = "PhosPeptides_express_diff.xlsx";
my $workbook = Excel::Writer::XLSX->new("$outPath/$outfile1");
my @ratioindex = keys %excelHash;
foreach my $ratio_index (sort {$a cmp $b} @ratioindex) {
    (my $sheetName = $ratio_index) =~ s/-/vs/;
    my $worksheet = $workbook->add_worksheet($sheetName);
    my $format_head = $workbook->add_format(%font1); # Add a format
    my $format_cont = $workbook->add_format(%font2); # Add a format
    $worksheet->freeze_panes(1, 2);
    $worksheet->set_column('A:C', 20);
    my $head1 = $head1Hash{$ratio_index};
    my @head1 = split "\t", $head1;
    my $columNum = @head1;
    $worksheet->set_column(0, $columNum, 15);
    $worksheet->write_row(0, 0, \@head1, $format_head);
    my $row = 0;
    foreach my $n (sort {$a <=> $b} keys %{$excelHash{$ratio_index}}) {
        my $out = $excelHash{$ratio_index}{$n};
        my @out = split "\t", $out;
        $worksheet->write(++$row, 0, \@out, $format_cont);
    }

}
$workbook->close();
