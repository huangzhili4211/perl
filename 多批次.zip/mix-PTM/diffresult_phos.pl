#!/usr/bin/perl -w
use strict;
use Cwd;
use File::Basename;
my $path = getcwd;

my $outpath = $path . "/getdiff";
mkdir $outpath unless -d $outpath;

my $in = "Summary-Result.txt";
my $FC = 1.5;
$FC = $ARGV[0] if($ARGV[0]);
my @uniqratio;
open SR,"<$in";
chomp (my $firstline = <SR>);
close SR;
my @Firstarr = split "\t",$firstline;
#map{push (@uniqratio,$1),if $_ =~ /^(\d*:\d*)$/} @Firstarr;
map{push (@uniqratio,$1),if ($_ =~ /^([\d\D]*:[\d\D]*)$/ && $_ !~ /\s+/ && $_ !~ /mix/)} @Firstarr;
#print "@uniqratio\n";

###########��ò��쵰���б�#################
my $l;
my %headHash;
my %finHash;
my %statHash;
open DIF,"<$in";
my @head = ("Index", "Sequence", "Phos_seq", "Modification", "Batch-1 N", "Batch-1 Accessions", "Batch-2 N", "Batch-2 Accessions");
my $heahl = join "\t", @head;
while(<DIF>){
	$l++;
	chomp;
	my @items = split "\t";
	if ($l == 1) {
		for (my $i = 0; $i <= $#items; $i ++) {
			$headHash{$items[$i]} = $i;
		}
		foreach (@uniqratio) {
			(my $out_diff = $_) =~ s/:/-/;
			$out_diff .= "_diff.txt";
			$finHash{$_} = $out_diff;
			open TMP, ">$outpath/$out_diff";
			print TMP "$heahl\tDiff_state\t$_\tPVal $_\n";
			close TMP;

		}
	}else {
		my $mod = $items[$headHash{'Modification'}];
		if ($mod =~ /Phospho/) {
			for (my $k = 0; $k <= $#uniqratio; $k ++) {
				my $fc = $items[$headHash{$uniqratio[$k]}];
				my $pv = $items[$headHash{"PVal " . $uniqratio[$k]}];
				if ($fc ne "--") {
					$statHash{$uniqratio[$k]}{"Total"} ++;
				}
				next if ($pv eq "--" || $pv >0.05 || $fc eq "--" );
				my $stu;
				if ($fc >= $FC) {
					$stu = 'up';
					$statHash{$uniqratio[$k]}{"up"} ++;
					$statHash{$uniqratio[$k]}{"Alldiff"} ++;
				}elsif ($fc <= 1/$FC) {
					$stu = 'down';
					$statHash{$uniqratio[$k]}{"down"} ++;
					$statHash{$uniqratio[$k]}{"Alldiff"} ++;
				}else {
					next;
				}
				my @lines;
				map {push (@lines, $items[$headHash{$_}])} @head;
				my $Line = join "\t", @lines;
				open OUT,">>","$outpath/$finHash{$uniqratio[$k]}";
				print OUT "$Line\t$stu\t$fc\t$pv \n";
				close OUT;
			}
		}	
	}
}
close DIF;

my $staf = "Alldiff_stat.txt";
open STAT,">>","$outpath/$staf";
my @stats = ("Total", "up", "down", "Alldiff");
print STAT "\|FC\|=$FC\n";
my $stats = join "\t", @stats;
print STAT "\t$stats\n";
foreach my $cp (sort {$a cmp $b} keys %statHash) {
	my @value;
	map	{push (@value, $statHash{$cp}{$_})} @stats;
	my $value = join "\t", @value;
	print STAT "$cp\t$value\n";
}
close STAT;


########## get .glist ##########

my @fiarr = glob "$outpath/*_diff.txt";
foreach (sort {$a cmp $b} @fiarr){
	my $f = basename $_;
	my $cp = $1 if $f =~ /([^_]+)/;
	(my $ncp = $cp )=~ s/-/:/g;
	print "$ncp\n";
	my $l;
	my %headHash;
	my $glist = $cp . ".glist";
	open IN,"<$outpath/$f";
	open GL,">$outpath/$glist";
	my @Aind;
	my $loged = 1;
	my %accHash;
	while(<IN>){
		$l ++;
		chomp;
		my @items = split "\t";
		if ($l == 1){
			for (my $i = 0; $i <= $#items; $i++){
				$headHash{$items[$i]} = $i;
				push (@Aind, $i) if $items[$i] =~ /Accessions/;
			}
		}else {
			map {$accHash{$1} ++ if $items[$_] =~ /^([^;]+)/} @Aind;
			#my $loged = log($items[$headHash{$ncp}])/log(2);
		}
	}
	my @accs = keys %accHash;
	map {print GL "$_\t$loged\n"} @accs;
	close GL;
	close IN;
}

	