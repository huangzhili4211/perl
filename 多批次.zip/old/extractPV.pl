use warnings;
use strict;

###First step###
my @farr = glob"norm*";
my $nbat = scalar @farr;
my $n;
my $headstr = "Accession\tName\tSpecies\tProtein Mass\tProtein Length";
my @headarr = split"\t",$headstr;
my @comparr;  #unique ratio within header line

foreach (@farr){
	my $fi = $_;
	my $fo;
	$fo = "Acc-"."$1".".txt" if $fi =~ /(\d)/;
	my $No = $1 if $fi =~ /(\d)/;
	if ($No==1){
		open HE,"<","norm_protein_summary-1.txt";
		my $FirL = <HE>;
		@comparr = split "\t",$FirL;
		@comparr = grep{/^\d*:\d*/} @comparr;
		close HE;
	}
	my $N;
	my %headhash;

	my @RatioIndArr;
	my @InfoIndArr;
	
	my @RatioArr;
	my $RatioStr;
	
	
	open IN,"<","$fi";
	open OUT,">","$fo";
	while(<IN>){
		$N++;
		chomp(my $Line = $_);
		my @Linarr = split "\t",$Line;
		if ($N == 1){
			for(my $i=0;$i<=$#Linarr;$i++){
				$headhash{$Linarr[$i]} = $i;
				for (my $e=0;$e<=$#headarr;$e++){
					push (@InfoIndArr,$i) if $Linarr[$i] eq $headarr[$e];
				}
				next if $Linarr[$i] =~ /^#/;
				if ($Linarr[$i] =~ /(\d*:\d*)/){
					my $Ra;
					if ($Linarr[$i] =~ /^(\d*:\d*)/){
						$Ra = "Batch-"."$No"." $1";
					}else{
						$Ra = "Batch-"."$No"." PVal"." $1";
					}
					push (@RatioArr,$Ra);
					push (@RatioIndArr,$i);
				}
				$RatioStr = join "\t",@RatioArr;
			}
			print OUT"N\t$headstr\t$RatioStr\n";
		}else{
			$N--;
			print OUT"$N\t";
			$N++;
			my @tmpinfoarr;
			my @tmpratioarr;
			map {push (@tmpinfoarr,$Linarr[$_])} @InfoIndArr;
			map {push (@tmpratioarr,$Linarr[$_])} @RatioIndArr;
			my $tmpinfoline = join"\t",@tmpinfoarr;
			my $tmpratioline = join"\t",@tmpratioarr;
			print OUT"$tmpinfoline\t$tmpratioline\n";
		}
	}
	close IN;
	close OUT;
}

####Second step: combine ####
my @flist = glob "Acc-*";
#print "@flist";
my %Allhash;
my %Allheadhash;
my @Allheadarr;
my @Allistarr;

foreach my $inf (@flist){
	my $c;
	my %headhash;
	open LI,"<","$inf";
	while(<LI>){
		$c++;
		chomp;
		my @items = split "\t";
		if ($c==1){
			for (my $q=0;$q<=$#items;$q++){
				$headhash{$items[$q]} = $q;
				next if exists $Allheadhash{$items[$q]};
				push (@Allheadarr,$items[$q]);
				$Allheadhash{$items[$q]} = 1;
			}
		}else{
			next if exists $Allhash{$items[$headhash{'Accession'}]};
			my $NewLine = "$items[$headhash{'Accession'}]\t$items[$headhash{'Name'}]\t$items[$headhash{'Species'}]\t$items[$headhash{'Protein Mass'}]\t$items[$headhash{'Protein Length'}]";
			$Allhash{$items[$headhash{'Accession'}]} = $NewLine;
			push (@Allistarr,$items[$headhash{'Accession'}]);
		}
	}
	close LI;
}

###### get All_ID.fasta #####
my %Allisthash;
map {$Allisthash{$_}=1} @Allistarr;

my @dbf = glob"*.fasta";
my $fa = shift @dbf;
open FA,"<","$fa";
open FAO,">","All_ID.fa";
$/='>';<FA>;$/="\n";
while(<FA>){
	chomp;
	my $name=$_;
	$/='>';
	my $con=<FA>;
	chomp $con;
	$con=~s/\n//g;
	$/="\n";
	my $id;
	my $acc = $1 if $name =~ /([^ ]+)/;
	my $des = $2 if $name =~ /[^ ]+(.*)/;
	$id = $1 if $acc =~ /(gi\|[0-9]*)/;
	$id = $acc if $acc =~ /^tr|/ || $acc =~ /^sp|/;
	if(exists $Allisthash{$id}){
		print FAO">$name\n$con\n";	
	}
}
close FA;
close FAO;

#############################

my $Allheadstr = join "\t",@Allheadarr;

my $Num = scalar @comparr;
$Num = $Num*2;
my $empstr = "-"x$Num;
my @emparr = split "",$empstr;
$empstr = join "\t",@emparr;


my $cl;
open RE,">","SummaryResult.txt";
print RE"$Allheadstr\n";
foreach (@Allistarr){
	$cl++;
	my $Acc = $_;
	print RE"$cl\t$Allhash{$Acc}\t";
	for (my $f=0;$f<=$#flist;$f++){
		my $tpf = $flist[$f];
		my $tn;
		my %tpheadhash;
		my %tphash;
		
		my @tmpratioIndarr;
		
		open FI,"<","$tpf";
		while(<FI>){
			$tn++;
			chomp;
			my @lr = split"\t";
		  #my @lrr= grep {/\d*:\d*/} @lr;
		  if ($tn==1){
		  	for (my $r=0;$r<=$#lr;$r++){
		  		$tpheadhash{$lr[$r]} = $r;
		  		push (@tmpratioIndarr,$r) if $lr[$r] =~ /\d*:\d*/;
		  	}
		  }else{
		  	my @tmparr;
		  	my $tmpstr;
		  	map {push(@tmparr,$lr[$_])}@tmpratioIndarr;
		  	$tmpstr = join "\t",@tmparr;
		  	$tphash{$lr[$tpheadhash{'Accession'}]} = $tmpstr;
		  }
		}
  	close FI;
  	if (exists $tphash{$Acc}){
  		print RE"$tphash{$Acc}";
  	}else{
  		print RE"$empstr";
  	}
  	print RE"\t" if $f!=$#flist;
  	print RE"\n" if $f==$#flist;
	}
}
close RE;

######Third step: reorder header line######

my @reorder;
my @reorderind;
open SUM,"<","SummaryResult.txt";
chomp (my $Header = <SUM>);
close SUM;
my @Headarr = split"\t",$Header;
for (my $z=0;$z<=$#Headarr;$z++){       # initiate new header line (only 6 elements)
	if (not $Headarr[$z] =~ /\d*:\d*/){
		push (@reorderind,$z);
		push (@reorder,$Headarr[$z]);
	}
}
for (my $a=0;$a<=$#comparr;$a++){       # add complete new header line (more elements)
	for (my $e=0;$e<=$#Headarr;$e++){
		my $po = index ($Headarr[$e],$comparr[$a]);
		push (@reorder,$Headarr[$e]) if $po != -1;
		push (@reorderind,$e) if $po != -1;
	}
}

#

my $reheadstr = join "\t",@reorder;
my $cc;
#my %sumheadhash;
open ORD,"<","SummaryResult.txt";
open RES,">","reorder_SummaryResult.txt";
while(<ORD>){
	$cc++;
	chomp (my $LL = $_);
	my @Lar = split"\t",$LL;
	if ($cc==1){
		#for (my $x=0;$x<=$#Lar;$x++){
		#	$sumheadhash{$Lar[$x]} = $x;
		#}
		print RES"$reheadstr\n";
	}else{
		my @tmpratioarr;
		map {push (@tmpratioarr,$Lar[$_])}@reorderind;
		my $tmpratiostr = join "\t",@tmpratioarr;
		print RES"$tmpratiostr\n";
	}
}
close ORD;
close RES;

#####Fourth step: get Mean and select PVal #######
=pod
open RES,"<","reorder_SummaryResult.txt";
chomp (my $View = <RES>);
close RES;
my @Vr = split "\t",$View;
foreach my $v (@comparr){
	foreach my $b (@Vr){
		my $ps = index ($b,$v);
		if $ps==8;
		next unless $ps =~ /\d*:\d*/;
=cut

my $d;
my %ordheadhash;
#my @Header4filter = @reorder;
#my @HeaderInd4filter = @reorderind;
my @macarr;
my @macIndarr;

my @infoitems;
my @infoInditems;
#my %arhash;
#map{$arhash{$_}=1}  = @headarr;

open RES,"<","reorder_SummaryResult.txt";
open RE4FIL,">","reorder_SummaryResult-2.txt";

while(<RES>){
	$d++;
	chomp (my $View = $_);
	my @Vr = split "\t",$View;
	if ($d==1){
		for (my $g=0;$g<=$#Vr;$g++){
			$ordheadhash{$Vr[$g]} = $g;
			push (@infoitems,$Vr[$g]) if (not $Vr[$g] =~ /\d*:\d*/);
			push (@infoInditems,$g) if (not $Vr[$g] =~ /\d*:\d*/);
		}
		for (my $v=0;$v<=$#comparr;$v++){
			my @micarr;
			my @micIndarr;
			my @microarr = grep {/($comparr[$v])/}@Vr;
			for (my $w1=0;$w1<=$#microarr;$w1++){
				if (not $microarr[$w1] =~ /PVal/){
					push (@micarr,$microarr[$w1]);
					#print "$microarr[$w]\n";
					for (my $y1=0;$y1<=$#Vr;$y1++){
						push (@micIndarr,$y1) if $Vr[$y1] eq $microarr[$w1];
					}
				}
			}
			for (my $w2=0;$w2<=$#microarr;$w2++){
				if ($microarr[$w2] =~ /PVal/){
					push (@micarr,$microarr[$w2]);
					#print "$microarr[$w]\n";
					for (my $y2=0;$y2<=$#Vr;$y2++){
						push (@micIndarr,$y2) if $Vr[$y2] eq $microarr[$w2];
					}
				}
			}
			push (@macarr,$_) for @micarr;
			push (@macIndarr,$_) for @micIndarr;
		}
		my $macstr = join "\t",@macarr;
		print RE4FIL"N\t$headstr\t$macstr\n";
		#map {print RE4FIL"$_\t"} @macarr;
		#print "@macIndarr";
		#my $microstr = join "\t",@micarr;
	}else{
		map {print RE4FIL"$Vr[$_]\t"} @infoInditems;
		map {print RE4FIL"$Vr[$_]\t"} @macIndarr;
		print RE4FIL"\n";
	}
}
close RES;
close RE4FIL;

##### get diff result ##########################
# extract max or min P-Value within all batchs #
# max or min Value is set.                     #
################################################
my $coul;
my %fiheadhash;
my %rev_fiheadhash;

my @NewLinarr;
my @NewIndLinarr;

my $mul = 2*$nbat;

my %PVRahash;
open FN,"<","reorder_SummaryResult-2.txt";
open FO,">","SummaryResult4diff.txt";
while(<FN>){
	$coul++;
	chomp(my $lin = $_);
	my @liar = split "\t",$lin;
	if ($coul==1){
		for (my $u=0;$u<=$#liar;$u++){
			$fiheadhash{$liar[$u]} = $u;
		}
		foreach my $tpcp (@comparr){
			my @PVarr;
			my %PVhash;
			for (my $o=0;$o<=$#liar;$o++){
				my $patt = "PVal $tpcp";
				#print "$patt\t";
				next if exists $PVhash{$o};
				push (@PVarr,$o) if $liar[$o] =~ /($patt)/;
				$PVhash{$o} = 1 if $liar[$o] =~ /($patt)/;
				next if $liar[$o] =~ /PVal/;
				next unless $liar[$o] =~ /\d*:\d*/;
				push (@NewLinarr,$liar[$o]) if $liar[$o] =~ /($tpcp)/;
				push (@NewIndLinarr,$o) if $liar[$o] =~ /($tpcp)/;
			}
			#print "$tpcp\n";
			$PVRahash{$tpcp} = \@PVarr;
			#print values %PVhash;
		}
		foreach (@comparr){
			my $tptr = "$_\tPVal $_";
			push (@NewLinarr,$tptr);
		}
		my $NewLinstr = join "\t",@NewLinarr;
		print FO"N\t$headstr\t$NewLinstr\n";
		%rev_fiheadhash = reverse %fiheadhash;
	}else{
		map {print FO"$liar[$_]\t"} @infoInditems;
		map {print FO"$liar[$_]\t"} @NewIndLinarr;
		#print FO"\n";
		#print "$liar[$fiheadhash{'Accession'}]\n";
		#print "@NewIndLinarr\n";
		
		for (my $tr=0;$tr<=$#NewIndLinarr;$tr+=$nbat){
			my $cc = $tr;
			#print "$NewIndLinarr[$tr]\t";
			#print "$tr\t$NewIndLinarr[$tr]\t";
			my $tpra = $1 if $rev_fiheadhash{$NewIndLinarr[$tr]} =~ /(\d*:\d*)/;
			my @ref2arr = @{$PVRahash{$tpra}};     # get 2 P-value index
			my @pvarr = map{$liar[$_]} @ref2arr;   # get 2 P-value in array
			#print "@ref2arr\t";
			
			my @combind;                  				 # get 2 Ratios index in array
			for (my $tp=1;$tp<=$nbat;$tp++){
				push (@combind,$NewIndLinarr[$tr]);
			  $tr++ if $tp<$nbat;
				#print "@comb\t";
			}
			my @comb = map{$liar[$_]} @combind;    # get 2 Ratios in array
			$tr = $cc;
			
			my $Mean = &get_Mean(\@comb);
			my $Pval = &get_PV(\@pvarr);
			
			print FO"$Mean\t$Pval\t";
		}
		print FO"\n";
	}
}
#print "@NewLinarr\n";
#print "@NewIndLinarr\n";
close FN;
close FO;

sub get_Mean{
	my $ratref = shift;
	my @ratarr = @$ratref;
	my $nx = scalar @ratarr;
	my $px=0;
	my @senarr;
	my $Me;
	map {push (@senarr,$_),if not $_ eq '-'} @ratarr;
	map {$px++,if $_ eq '-'} @ratarr;
	my $de = $nx - $px;
	if ($de == 1){
		$Me = shift @senarr;
	}elsif($de == 0){
		$Me = '-';
	}else{
		my $Sum;
		map {$Sum+=$_}@senarr;
		$Me = $Sum/$de;
	}
	return $Me;
}
	
sub get_PV{
	my $pvref = shift;
	my @fpvarr = @$pvref;
	my @filarr;
	my $fpv;
	my $nonc=0;
	map {$nonc++,if $_ eq '-'}@fpvarr;
	if ($nonc == scalar @fpvarr){
		$fpv = '-';
	}else{
		map {push(@filarr,$_),if $_ ne '-'}@fpvarr;
		my @sorted = sort{$a<=>$b}@filarr;
		$fpv = shift @sorted;
	}
	return $fpv;
}