use strict;
use warnings;
use Cwd;
=pod
my $nowPath = getcwd;

my $prjdir = $nowPath;
$prjdir .= "/before_combined_diff_Result";
#my $prjdir = "before_combined_diff_Result";
mkdir $prjdir unless -d $prjdir;
$prjdir =~ s/\//\\/g;


my $inf = shift;
$inf = "SummaryResult4diff.txt" unless -e $inf;
=cut
my @uniqratio;
open FIR,"<","SummaryResult4diff.txt";
chomp (my $firstline = <FIR>);
close FIR;
my @Firstarr = split "\t",$firstline;
map{push (@uniqratio,$1),if $_ =~ /^(\d*:\d*)$/} @Firstarr;
#print "@uniqratio";

my $N;
my @ratioIndarr;
my @pvIndarr;
my %finhash;
my %headhash;
my %rev_headhash;
open DIF,"<","SummaryResult4diff.txt";
while(<DIF>){
	$N++;
	chomp (my $Line = $_);
	my @Linarr = split "\t",$Line;
	if ($N==1){
		for (my $i=0;$i<=$#Linarr;$i++){
			$headhash{$Linarr[$i]} = $i;
		}
		for (my $k=0;$k<=$#uniqratio;$k++){
			for (my $j=0;$j<=$#Linarr;$j++){
				push (@ratioIndarr,$j) if $Linarr[$j] eq $uniqratio[$k];
				push (@pvIndarr,$j) if $Linarr[$j] =~ /^PVal ($uniqratio[$k])/;
			}
		}
		foreach (@uniqratio){
			my $tpra = $_;
			$tpra =~ s/:/-/;
			my $outn = "$tpra"."_diff.txt";
			#my $glist = "$tpra".".glist";
			$finhash{$_} = $outn;
			open TMP,">","$outn";
			print TMP"N\tAccession\tName\tDiff_state\t$_\tPVal $_\n";
			close TMP;
		}
		%rev_headhash = reverse %headhash;
	}else{
		$N--;
		for (my $r=0;$r<=$#ratioIndarr;$r++){
			for (my $t=0;$t<=$#pvIndarr;$t++){
				#print $Linarr[$ratioIndarr[$r]];
				#print "$r\t$t\t";
				next unless $r == $t;
				#print "$r\t$t\t";
				next if ($Linarr[$pvIndarr[$t]] eq '-' or $Linarr[$pvIndarr[$t]] > 0.05);
				next if $Linarr[$ratioIndarr[$r]] eq '-';
				my $stu;
				if ($Linarr[$ratioIndarr[$r]]>=1.5){
					$stu = 'up';
				}elsif ($Linarr[$ratioIndarr[$r]]<=0.666666667){
					$stu = 'down';
				}else{
					next;
				} 
				my $NewLine = "$N\t$Linarr[$headhash{'Accession'}]\t$Linarr[$headhash{'Name'}]\t$stu\t$Linarr[$ratioIndarr[$r]]\t$Linarr[$pvIndarr[$t]]\n";
				#print "OK";
				#print "$rev_headhash{$ratioIndarr[$r]}\t";
				open OUT,">>","$finhash{$rev_headhash{$ratioIndarr[$r]}}";
				print OUT"$NewLine";
				close OUT;
			}
			#print "\n";
		}
		$N++;
	}
}
close DIF;

##### get down/up_ID.fasta #####
my %fastahash;
open FA,"<","All_ID.fa";
$/='>';<FA>;$/="\n";
while(<FA>){
	chomp;
	my $name=$_;
	$/='>';
	my $con=<FA>;
	chomp $con;
	$con=~s/\n//g;
	$/="\n";
	my $id;
  my $acc = $1 if $name =~ /([^ ]+)/;
  my $des = $1 if $name =~ /[^ ]+(.*)/;
	$id = $1 if $acc =~ /(gi\|[0-9]*)/;
	$id = $acc if $acc =~ /^tr|/ || $acc =~ /^sp|/;
	$fastahash{$id} = ">$id $des\n$con\n";
}
close FA;

my @fiarr = glob"*_diff.txt";
my $staf = "Alldiff_stat.txt";
open STAT,">>","$staf";
foreach (@fiarr){
	#print "$_";
	my $f = $_;
	my $trn = $1 if $f =~ /(\d*-\d*)/;
	my $trn2 = $trn;
	$trn2 =~ s/-/:/g;
	#print "$f\t$tr\n";
	my $nc;
	my %faheadhash;
	my $downf = "$trn"."_down_ID.fa";   #114-113
	my $upf = "$trn"."_up_ID.fa";
	my $glist = "$trn".".glist";
	
	my $stup;
	my $stdown;
	
	open DOWN,">","$downf";
	open UP,">","$upf";
	open IN,"<","$f";
	open GL,">","$glist";
	
	while(<IN>){
		$nc++;
		chomp;
		my @larr = split "\t";
		if ($nc==1){
			for (my $k=0;$k<= $#larr;$k++){
				$faheadhash{$larr[$k]} = $k;
			}
		}else{
			my $loged = log($larr[$faheadhash{$trn2}])/log(2);
			print GL"$larr[$faheadhash{'Accession'}]\t$loged\n";
			print UP"$fastahash{$larr[$faheadhash{'Accession'}]}" if $larr[$faheadhash{'Diff_state'}] eq 'up';
			$stup++ if $larr[$faheadhash{'Diff_state'}] eq 'up';
			print DOWN"$fastahash{$larr[$faheadhash{'Accession'}]}"  if $larr[$faheadhash{'Diff_state'}] eq 'down';
			$stdown++ if $larr[$faheadhash{'Diff_state'}] eq 'down';
		}
	}
	$nc--;
	print STAT"$trn:\ndiff: $nc\tup: $stup\tdown: $stdown\n\n";
	close DOWN;
	close UP;
	close IN;
}
close STAT;
	
##### get up/down.glist #####
#foreach (@fiarr){