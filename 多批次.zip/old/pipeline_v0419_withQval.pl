#!/perl -w
use strict;
use diagnostics;
use Getopt::Long;
use File::Path qw(mkpath);
use File::Basename;
use Bio::Tools::SeqStats;
use Spreadsheet::WriteExcel;
use Cwd;

our $nowPath = getcwd;
our $R = "R";
our $prjdir = $nowPath;


my $file1 = "MZ.txt";
our $outName;
if($file1 =~/(.*)\.txt/){
	$outName = $1;
}
#my $file2 = "norm_protein_summary-2_257.txt";

my %all_info_hash =();
our @markers = (113..130);
=pod
my @marker1 = (114..116);
my @marker2 = (117..119);
my @marker3 = (120..122);
my @marker4 = (123..125);
my %sampleHash = (
	'TH313_18hvsTH313' => \@marker1,
	'TH257_18hvsTH257' => \@marker2,
	'TH313vsTH257' => \@marker3,
	'TH313_18hvsTH257_18h' =>\@marker4
);
=cut
my @marker1 = (113,114,115);
my @marker2 = (116,117,118);
my @marker3 = (119,120,121);
my @marker4 = (122,123,124);
my @marker5 = (125,126,127);
my @marker6 = (128,129,130);
my %sampleHash =(
   'M95vsM10' => \@marker1,
   'M95vsM18' => \@marker2,
   'M10vsM18' => \@marker3,
   'Z96vsZ06' => \@marker4,
   'Z96vsZ13' => \@marker5,
   'Z06vsZ13' => \@marker6
);

my %hash1 = read_protein_file($file1);
#my %hash2 = read_protein_file($file2);
#my %hash = (%hash1,%hash2);
my %hash = %hash1;


my @headArray = ("Accession");
map{push(@headArray,$_)} @markers;
foreach (keys %sampleHash) {
	my $rh = $_." Ratio";
	#my $cvHead = $_." CV";
	#my $pvalueHead = "PVal ".$_."_P-value";
	my $pvalueHead = "PVal ".$_;
	my $qvalueHead = "Qval ".$_;
	#my $sdHead = $_." SD";
	my $sdHead = "SD ".$_;
	#my $qvalueHead = $_." Q-value";
	push(@headArray,$rh,$sdHead,$pvalueHead,$qvalueHead);
}





my %hash4Pvalue = ();
my %tmpRatioHash = ();
foreach my $acc (keys %hash) {
	$all_info_hash{$acc}{"Accession"} = $acc;
	foreach my $sample (keys %sampleHash) {
		my @tmpMarkers = @{$sampleHash{$sample}};
		my @ratios = ();
		foreach my $marker (@tmpMarkers) {
			my $abund1 = (exists $hash1{$acc} && exists $hash1{$acc}{$marker})? $hash1{$acc}{$marker} : 'NA';
			#my $abund2 = (exists $hash2{$acc} && exists $hash2{$acc}{$marker})? $hash2{$acc}{$marker} : 'NA';
			#my $ratio = get_ratio($abund1,$abund2); 
			my $ratio = "NA";
			$ratio = $abund1 if ($abund1 ne "NA" && $abund1 != 0);
			$tmpRatioHash{$acc}{$sample}{$marker} = $ratio;
			push(@ratios,$ratio) if ($ratio ne "NA" && $ratio != 0);
			$all_info_hash{$acc}{$marker} = $ratio;
		}
		my $mean = get_mean(@ratios);
		my $sdvalue = get_sd(@ratios);
		#my $cv = get_cv(@ratios);
		my $ratioHead = $sample.' Ratio';
		my $sdHead = 'SD '.$sample;
		#my $cvHead = $sample.' CV';
		$all_info_hash{$acc}{$ratioHead} = $mean;
		$all_info_hash{$acc}{$sdHead} = $sdvalue;
		#$all_info_hash{$acc}{$cvHead} = $cv;
		my @logRatios = ();
		#my @logRatios = get_log_ratio(@ratios);
		map{my $loged = log($_)/log(2) if($_!=0);push(@logRatios,$loged) if($_!=0)} @ratios;
		$hash4Pvalue{$sample}{$acc} = \@logRatios;
	}
}

foreach my $sample (keys %hash4Pvalue) {
	my %pvalueHash = ();
	my %qvalueHash = ();
	my $file4Pvalue = $sample."4.pvl";
	open OUT1,">$file4Pvalue" or die;
	foreach my $acc (keys %{$hash4Pvalue{$sample}}) {
		my $ratios = $hash4Pvalue{$sample}{$acc};
		my @ratios = @$ratios;
		my $rr = join ",",@ratios;
		print OUT1"$acc\t$rr\n" ;#if @ratios > 2 ;
	}
	close OUT1;
	get_pvalue2($sample, $file4Pvalue,\%pvalueHash);
	%qvalueHash = BenjaminiCorrelation(\%pvalueHash);
	my $pvalueHead = "PVal ".$sample;
	my $qvalueHead = "Qval ".$sample;
	foreach my $acc (keys %all_info_hash) {
		my $pval = "--";
		my $qval = "--";
		$pval = $pvalueHash{$acc}{$sample} if exists $pvalueHash{$acc}{$sample};
		$qval = $qvalueHash{$acc}{$sample} if exists $qvalueHash{$acc}{$sample};
		$all_info_hash{$acc}{$pvalueHead} = $pval;
		$all_info_hash{$acc}{$qvalueHead} = $qval;
		#print "##$acc## ---- $pval\n";
		
		#print "$acc----$pvalueHead----$pvalueHash{$acc}\n";
		#$all_info_hash{$acc}{$qvalueHead} = $qvalueHash{$acc};
	}
}


write_output_result($outName,\%all_info_hash,\@headArray);

##############################################################
sub read_protein_file {
	my $file = shift;
	my %headHash = ();
	my @items = ();
	my $l = 0;
	#my $markerHead;
	my %inhash = ();
	open IN,"$file" or die;
	while (<IN>) {
		chomp;
		$l ++;
		@items = split /\t/;
		if ($l == 1) {
			for(my $i=0;$i<=$#items;$i++) {
				$headHash{$items[$i]} = $i;
			}
		}else {
			my $id = $items[$headHash{'Accession'}];
			foreach my $marker (@markers) {
				my $abund = defined $items[$headHash{$marker}] && $items[$headHash{$marker}] =~ /[\d\D]+/? $items[$headHash{$marker}] : 0;
				$inhash{$id}{$marker} = $abund; #abundance
			}
		}
	}
	close IN;
	return %inhash;
}
########################################

sub get_pvalue2{
	my ($mark,$f,$hash_ref) = @_;
	my %hash = ();
	my $pvalueF = $mark.'.pval.pval';
	my $R_code1 = <<TTEST;	
c<-file("$prjdir/$f","r")
while(TRUE) {
    r1<-readLines(c,n=1)
    if(length(r1) == 0) {
	break
    }else {
	r<-strsplit(r1,split="\t")
	str<-r[[1]][1]
	#str<-as.numeric(str[[1]])
	abunds1 <- r[[1]][2]
	abund11<-strsplit(abunds1[[1]],split=",")	
	abund1<-as.numeric(abund11[[1]])
     if(length(unique(abund1))==1&&length(abund1)>1){
		cc<-c(str,0)
		}else if(length(unique(abund1))==1&&length(abund1)==1){
			next
			}else{
	t<-t.test(abund1,mu=0)
	cc<-c(str,t\$p.value)       
         }
   
	cat(cc,file="$pvalueF",sep="\t",append=TRUE)
	cat("\n",file="$pvalueF",append=TRUE)
    }
}
close(c)
TTEST
	open R,"| $R --vanilla --slave" or die "$!";
	print R $R_code1;
	close R;
	open PF,"<$pvalueF" or die"cant open result.p:$!";
	while(<PF>) {
		chomp;
		my @items = split /\t/;
		#$hash{$items[0]} = $items[1];
		$hash_ref -> {$items[0]} -> {$mark} = $items[1];
	#print "$items[0]-----$items[1]\n";
	}
	close PF;
	#unlink $pvalueF;
	#unlink $f;
	return %hash;
}

##########################################################################


sub BenjaminiCorrelation {
    my $h = shift;
    my %hash = %$h;
    #my $m = scalar (keys %hash);
    my %outHash = ();
    my %tmpHash = ();
    foreach my $n (keys %hash) {
	foreach my $samp (keys %{$hash{$n}}) {
	    my $pvalue = $hash{$n}{$samp};
	    #$tmpHash{$samp}{$n}=$pvalue;
	    $tmpHash{$samp}{$n}=$pvalue if($pvalue ne "--");
	}
    }
    foreach my $samp (keys %tmpHash) {
	my $i = 0;
	 my $m=scalar(keys %{$tmpHash{$samp}});
	 print"$m\n";
	foreach my $n (sort {$tmpHash{$samp}{$a} <=> $tmpHash{$samp}{$b}} keys %{$tmpHash{$samp}}) {
	    $i ++;
	    my $pvalue = $tmpHash{$samp}{$n};
	    my $q = $m*$pvalue/$i;
	    $outHash{$n}{$samp} = $q;
	}
    }
    return %outHash;
}

########################################

sub write_output_result {
    my ($mark,$h,$h2) = @_;
    my %outputHash = %$h;
    my @headArray = @$h2;
    my $workbookFile = $mark.'_Summary-Result.xls';
    my $outFile = $mark.'_Summary-Result.txt';
    open OUT,">$prjdir/$outFile" || die "cant open $prjdir/$outFile:$!";
    my $workbook = Spreadsheet::WriteExcel->new("$prjdir/$workbookFile");
    my %font = (
	    font  => 'New Times Roman',
	    size  => 11,
	    color => 'white',
	    bold  => 1,
	    align => 'center',
	    bg_color => 'purple',
	    valign => 'vcenter',
	    text_wrap => 1,
	);
    my %font2 = (
	    font => 'New Times Roman',
	    size => 11,
	    pattern => 0,
	    color => 'black',
	);
    my $format_head = $workbook -> add_format(%font);
    my $format_cont = $workbook -> add_format(%font2);
    my $sheetName = $mark.'_Summary-Result';
    my $worksheet = $workbook -> add_worksheet($sheetName);
    my $columNum = @headArray;
    my $headString = join "\t",@headArray;
    print OUT"$headString\n";
    $worksheet -> freeze_panes('A2'); # Freeze the first row
    $worksheet->set_column('A:C', 20);
    $worksheet -> set_column(0,$columNum,15);
    $worksheet -> write_row(0,0,\@headArray,$format_head);
    my $row = 0;
    foreach my $item (sort {$a cmp $b}keys %outputHash) {
	my @tmpArray = ();
	foreach my $head (@headArray) {
	    my $value = exists $outputHash{$item}{$head}? $outputHash{$item}{$head}:'--';
	    #print "$value\n" if $head =~/P-value/;
	    push(@tmpArray,$value);
	}
	$worksheet -> write(++$row,0,\@tmpArray,$format_cont);
	my $outLine = join "\t",@tmpArray;
	print OUT"$outLine\n";
    }
    $workbook -> close();
}

################################################
sub get_mean{
	my @ratio=@_;
	my @finalratio;
	my $sum;
	map{push(@finalratio,$_) if($_!=0)} @ratio;
	map{$sum+=$_} @finalratio;
	my $meanRatio;
	if(@finalratio>=1){
		$meanRatio=$sum/@finalratio;
  }else{
  	$meanRatio="--"; 		
    }
      	
  my @finalratio1=sort{$a <=>$b} @finalratio;
	my $n=scalar @finalratio1;
	my $median;
	if($n==0){
		$median="--";
		}else{
	if($n%2==0){
		$median=($finalratio1[($n/2)-1]+$finalratio1[($n/2)])/2;		
	}elsif($n%2==1){
		$median=$finalratio1[($n-1)/2];		
		}
	}	
	#print"@finalratio---$median\n";
	my $sumsd;
	map{my  $sum1=($_-$meanRatio)*($_-$meanRatio);$sumsd+=$sum1;} @finalratio;
	my $sd;

	if(@finalratio>1){
			$sd=sqrt($sumsd/((@finalratio)-1));	
    } else{
	     $sd="--";
	}
	#print"$ret\n";
	#my @result=($meanRatio,$median,$sd);
	
	
	#print"$meanRatio\n";
	return $meanRatio;
	
	
	}
	
	
	sub get_sd{
	my @ratio=@_;
	my @finalratio;
	my $sum;
	map{push(@finalratio,$_) if($_!=0)} @ratio;
	map{$sum+=$_} @finalratio;
	my $meanRatio;
	if(@finalratio>=1){
		$meanRatio=$sum/@finalratio;
  }else{
  	$meanRatio="--"; 		
    }
      	
  my @finalratio1=sort{$a <=>$b} @finalratio;
	my $n=scalar @finalratio1;
	my $median;
	if($n==0){
		$median="--";
		}else{
	if($n%2==0){
		$median=($finalratio1[($n/2)-1]+$finalratio1[($n/2)])/2;		
	}elsif($n%2==1){
		$median=$finalratio1[($n-1)/2];		
		}
	}	
	#print"@finalratio---$median\n";
	my $sumsd;
	map{my  $sum1=($_-$meanRatio)*($_-$meanRatio);$sumsd+=$sum1} @finalratio;
	my $sd;

	if(@finalratio>1){
			$sd=sqrt($sumsd/((scalar @finalratio)-1));
    } else{
	     $sd="--";
	}
	#print"$ret\n";
	#my @result=($meanRatio,$median,$sd);
	
	#return $meanRatio;
	return $sd;
	
	}
	